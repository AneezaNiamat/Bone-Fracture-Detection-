image_folder='E:\7th Semester\MATLAB\all'
filenames=dir(fullfile(image_folder,'*.jpg'))
total_images=numel(filenames);
for n=1:total_images
    f=fullfile(image_folder,filenames(n).name);
    our_images=imread(f)
    figure(n)
    imshow(our_images);
end
I=rgb2gray(our_images);
I= medfilt2(I,[7 7]);
KK=im2bw(I);
Cn=edge(KK,'canny',.05);
figure,imshow(Cn);


Can1=Cn;
Mean=mean(mean(Can1));
STD=std2(Can1);
Area=bwarea(Can1);
Pe=regionprops(Can1,'Perimeter');
Peri=Pe.Perimeter;

Ecc=regionprops(Can1,'Eccentricity');
Eccn=Ecc.Eccentricity;

Fea1={Mean ;STD ;Area ;Peri ;Eccn}
Fea12=[Mean STD Area Peri Eccn];
save Fea1;
ve1={'Mean';'STD';'Area';'Peri';'Eccn'};
w3(:,2)=ve1;
w3(:,3)=Fea1;

     %set(handles.uitable1,'data',w3);
     if(Fea12(n)==Fea(n))
         w8(n)={'Fractured'};
     else
         w8(n)={'Not Fractured'};
     end
    
 %w8=w8';
 %set(handles.uitable2,'data',w8);
 
 global our_images
global I
global bw
[filename pathname] = uigetfile({'*jpg'},'File Selector')
our_images =imread(filename)
I= imread(filename);
axes(handles.axes4);
imshow(I);
Igray =rgb2gray(I);
BW = edge(Igray,'canny');
figure(1)
uicontrol('Style','Checkbox','Callback',@canny,'String','Edge detection'),'Position',[20 20 100 20]
imshow(I)
function canny(src, event)
global I
global BW
if src.Value1
    imshow(BW)
else
    imshow(I)
end

     
         
